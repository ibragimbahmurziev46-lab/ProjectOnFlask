from app import app
from model import db, Student

with app.app_context():
    db.create_all()
    
    # Проверка, есть ли уже данные
    if Student.query.count() == 0:
        student1 = Student(name='Salman', age=32, phone_number='89005553535', email='salman@mail.ru')
        student2 = Student(name='Adam', age=50, phone_number='89280560606', email='adam@mail.ru')
        student3 = Student(name='Hamzat', age=20, phone_number='88007775757', email='hamzat@mail.ru')
        student4 = Student(name='Ulugbek', age=12, phone_number='Все семерки', email='twoturbo@mail.ru')
        student5 = Student(name='Hans', age=122, phone_number='Все тройки', email='turbotroika@mail.ru')
        db.session.add_all([student1, student2, student3, student4, student5])
        db.session.commit()
        print("База данных создана и заполнена")
    else:
        print("Данные уже есть в базе")