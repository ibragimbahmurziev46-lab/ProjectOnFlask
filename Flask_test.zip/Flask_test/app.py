from flask import Flask, render_template
from model import Student, db 
from flask_migrate import Migrate
import os

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///student.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)
migrate = Migrate(app, db)

@app.route('/users')
def users():
    stud_list = Student.query.all()
    return render_template('students.html', students=stud_list)

if __name__ == '__main__':
    app.run(debug=True)


app.app_context().push()